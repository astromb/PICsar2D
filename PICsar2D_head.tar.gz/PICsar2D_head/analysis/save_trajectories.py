import numpy as np
import sys
import pickle
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from file_reading import read_tracers_from_file
from math import pi
start_img_num = 0
end_img_num = 999
max_trajectory = end_img_num + 1
traj_min_length = 50
traj_dsample = 1

def update_traj_dict(traj_dict,p_arr):
    [sort_arr,x_arr,y_arr,z_arr,vx4_arr,vy4_arr,vz4_arr] = p_arr
    for n, key in enumerate(sort_arr):
        if(key[1]%traj_dsample == 0):
            if(not key in traj_dict):
                traj_dict[key] = {}
                traj_dict[key]['index'] = 0
                traj_dict[key]['x'] = np.zeros(max_trajectory)
                traj_dict[key]['y'] = np.zeros(max_trajectory)
                traj_dict[key]['z'] = np.zeros(max_trajectory)
                traj_dict[key]['vx4'] = np.zeros(max_trajectory)
                traj_dict[key]['vy4'] = np.zeros(max_trajectory)
                traj_dict[key]['vz4'] = np.zeros(max_trajectory)
            i = traj_dict[key]['index']
            traj_dict[key]['x'][i] = x_arr[n] 
            traj_dict[key]['y'][i] = y_arr[n]
            traj_dict[key]['z'][i] = z_arr[n]
            traj_dict[key]['vx4'][i] = vx4_arr[n] 
            traj_dict[key]['vy4'][i] = vy4_arr[n]
            traj_dict[key]['vz4'][i] = vz4_arr[n]
            traj_dict[key]['index'] = i+1
    return traj_dict

def trim_arrays(traj_dict):  
    keys = traj_dict.keys()
    for key in keys:
        i = traj_dict[key]['index']
        if(i < traj_min_length):
            del traj_dict[key]
        else:
            traj_dict[key]['x'] = traj_dict[key]['x'][:i]
            traj_dict[key]['y'] = traj_dict[key]['y'][:i]
            traj_dict[key]['z'] = traj_dict[key]['z'][:i]
            traj_dict[key]['vx4'] = traj_dict[key]['vx4'][:i]
            traj_dict[key]['vy4'] = traj_dict[key]['vy4'][:i]
            traj_dict[key]['vz4'] = traj_dict[key]['vz4'][:i]
    return traj_dict

#create dictionary by which to sift particles
traj_i_dict = {}
traj_e_dict = {}
for img_num in range(start_img_num,end_img_num+1):
    print img_num
    [pi_arr,pe_arr] = read_tracers_from_file(img_num)
    traj_i_dict = update_traj_dict(traj_i_dict,pi_arr)
    traj_e_dict = update_traj_dict(traj_e_dict,pe_arr)      

pickle.dump(trim_arrays(traj_i_dict),open(indir+"traj_i.p","w"))
pickle.dump(trim_arrays(traj_e_dict),open(indir+"traj_e.p","w"))
