import numpy as np #, pandas as pd
import csv
from math import sqrt
import random
import sys
from sim_pars import *
from file_reading import read_prtl_header, read_poynting, read_rot, read_inj
import os.path

if(len(sys.argv) > 1):
    start_img_num = int(sys.argv[1])
else:
    start_img_num = 0
    
if(len(sys.argv) > 2):
    end_img_num = int(sys.argv[2])
else:
    end_img_num = 1000
    
if(len(sys.argv) > 3):
    img_stride = int(sys.argv[3])
else:
    img_stride = 1
    
file_mult = 1
MPI_outdir = "../MPI_output/"
outdir = "../output/"

do_join_fields = True
do_join_fields_grid = True
do_join_prtls = True
do_join_currents = True
do_join_inj_vol = True
do_join_inj_surf = True
do_join_ptlg = True
do_join_ptlq = True
do_join_ptlj = True
do_join_poynt = True
do_join_rot = True
do_join_ptlv2 = True
do_join_tracers = True

def calc_prank(pr,pt):
    return pt*nproc_r + pr

def join_fields_n(img_num, n_flds, fname_prefix):
    #Check if file from root processor exists. If not, skip this file.
    fname_chk = MPI_outdir + fname_prefix + '.p' '%05d' % 0 + "." + '%05d' % (file_mult*img_num) + '.d'
    if(os.path.isfile(fname_chk)):
        print "joining " + fname_prefix + " " + str(img_num)
        fname_out = outdir + fname_prefix + '.' + '%05d' % img_num + '.d'
        f_out = open(fname_out, 'w')
        arr_dim_r = (Nr+2*Nghost_r*nproc_r+fdsample-1)/fdsample
        arr_dim_t = (Nt+2*Nghost_t*nproc_t+fdsample-1)/fdsample
        vol = arr_dim_r*arr_dim_t
        flds_n_arr = np.zeros((arr_dim_r,arr_dim_t,n_flds))
        for pr in range(0,nproc_r):
            if(pr < nproc_r -1):
                Nr_proc = Nr/nproc_r
            else:
                Nr_proc = Nr_proc_max
            for pt in range(0,nproc_t):
                fname_in = MPI_outdir + fname_prefix + '.p' '%05d' % calc_prank(pr,pt) + "." + '%05d' % (file_mult*img_num) + '.d'
                if(pt < nproc_t -1):
                    Nt_proc = Nt/nproc_t
                else:
                    Nt_proc = Nt_proc_max
    
                arr_dim_proc_r = (Nr_proc+2*Nghost_r*nproc_r+fdsample-1)/fdsample
                arr_dim_proc_t = (Nt_proc+2*Nghost_t*nproc_t+fdsample-1)/fdsample
                vol_proc = arr_dim_proc_r*arr_dim_proc_t
    
                #f = open(fname_in, 'r')
                #flts = pd.read_csv(f,header=None,squeeze=True).values
                #f.close()
                flts = np.genfromtxt(fname_in) 
                if(n_flds*vol_proc != len(flts)):
                    print "Nr_proc: ", Nr_proc, "Nt_proc: ", Nt_proc, "n_flds vol: ", n_flds*vol_proc, "len flts: ", len(flts)
                    raise ValueError("file length contradicts array lengths")
                flts = flts.reshape((arr_dim_proc_r,arr_dim_proc_t,n_flds),order='F')
                start_index_r = pr*((Nr/nproc_r+2*Nghost_r+fdsample-1)/fdsample)
                start_index_t = pt*((Nt/nproc_t+2*Nghost_t+fdsample-1)/fdsample)
                end_index_r = start_index_r + arr_dim_proc_r
                end_index_t = start_index_t + arr_dim_proc_t
                for fld_n in range(0,n_flds):
                    flds_n_arr[start_index_r:end_index_r,start_index_t:end_index_t,fld_n] = flts[:,:,fld_n]  
        flds_n_arr = flds_n_arr.reshape(vol*n_flds,order='F')
        f_out.writelines("%12.10f\n" % x for x in flds_n_arr)
        f_out.close()

def join_prtls(img_num,fname_prefix):
    #Check if file from root processor exists. If not, skip this file.
    fname_chk = MPI_outdir + fname_prefix + '.p' + '%05d' % 0 + "." + '%05d' % (file_mult*img_num) + '.d'
    if(os.path.isfile(fname_chk)):
        print "joining particles " + str(img_num)
        lines_glob=[]
        lines_glob_ion=[]
        lines_glob_lec=[]
        n_ions_glob = 0
        n_lecs_glob = 0
        n_ions_dsample_glob = 0
        n_lecs_dsample_glob = 0
        for pr in range(0,nproc_r):
            for pt in range(0,nproc_t):
                fname_in = MPI_outdir + fname_prefix + '.p' + '%05d' % (pt*nproc_r+pr) + "." + '%05d' % (file_mult*img_num) + '.d'
                f = open(fname_in,'r')
                lines = f.readlines()
                f.close()
                [n_ions,n_lecs,pdsample,n_ions_dsample,n_lecs_dsample] = read_prtl_header(lines[0])
                n_ions_glob += n_ions
                n_lecs_glob += n_lecs
                n_ions_dsample_glob += n_ions_dsample
                n_lecs_dsample_glob += n_lecs_dsample
                lines_glob_ion = lines_glob_ion + lines[1:n_ions_dsample+1]
                lines_glob_lec = lines_glob_lec + lines[n_ions_dsample+1:]
        lines_glob = [str(n_ions_glob) + ' ' + str(n_lecs_glob) + ' ' + str(pdsample) + ' ' + str(n_ions_dsample_glob) + ' ' + str(n_lecs_dsample_glob) +'\n'] + lines_glob_ion + lines_glob_lec
        fname_out = outdir + fname_prefix + '.' + '%05d' % img_num + '.d'
        f_out = open(fname_out, 'w')
        for line in lines_glob:
            f_out.write(line)
        f_out.close()
    
def join_poynting(img_num):
    #Check if file from root processor exists. If not, skip this file.
    fname_chk = MPI_outdir + 'pynt.p' + '%05d' % 0 + "." + '%05d' % (file_mult*img_num) + '.d'
    if(os.path.isfile(fname_chk)):
        print "joining poynting flux " + str(img_num)
        poynt_glob_arr=np.zeros(Nr)
        ion_glob_arr=np.zeros(Nr)
        lec_glob_arr=np.zeros(Nr)
        write_out_arr=np.zeros([Nr,4])
        for pr in range(0,nproc_r):
            if(pr < nproc_r -1):
                Nr_proc = Nr/nproc_r
            else:
                Nr_proc = Nr_proc_max
                
            start_index_r = pr*(Nr/nproc_r)
            end_index_r = start_index_r + Nr_proc
            for pt in range(0,nproc_t):
                fname_in = MPI_outdir + 'pynt.p' + '%05d' % (pt*nproc_r + pr) + "." + '%05d' % (file_mult*img_num) + '.d'
                [r_arr,poynt_proc_arr,ion_proc_arr,lec_proc_arr] = read_poynting(img_num,fname_in=fname_in)
                if(Nr_proc != len(r_arr)):
                    print "Nr_proc: ", Nr_proc, "len: ", len(r_arr)
                    raise ValueError("file length contradicts array lengths")
                poynt_glob_arr[start_index_r:end_index_r] += poynt_proc_arr
                ion_glob_arr[start_index_r:end_index_r] += ion_proc_arr
                lec_glob_arr[start_index_r:end_index_r] += lec_proc_arr
            write_out_arr[start_index_r:end_index_r,0] = r_arr
        write_out_arr[:,1] = poynt_glob_arr
        write_out_arr[:,2] = ion_glob_arr
        write_out_arr[:,3] = lec_glob_arr
        fname_out = outdir + 'pynt.' + '%05d' % img_num + '.d'
        np.savetxt(fname_out,write_out_arr)
    
def join_rot(img_num):
    #Check if file from root processor exists. If not, skip this file.
    fname_chk = MPI_outdir + 'rot.p' + '%05d' % 0 + "." + '%05d' % (file_mult*img_num) + '.d'
    if(os.path.isfile(fname_chk)):
        print "joining rotation profile " + str(img_num)
        write_out_arr=np.zeros([Nr,2])
        for pr in range(0,nproc_r):
            if(pr < nproc_r -1):
                Nr_proc = Nr/nproc_r
            else:
                Nr_proc = Nr_proc_max
            start_index_r = pr*(Nr/nproc_r)
            end_index_r = start_index_r + Nr_proc
            fname_in = MPI_outdir + 'rot.p' + '%05d' % pr + "." + '%05d' % (file_mult*img_num) + '.d'
            [r_arr,rot_arr] = read_rot(img_num,fname_in=fname_in)
            if(Nr_proc != len(r_arr) or Nr_proc != len(rot_arr)):
                print "Nr_proc: ", Nr_proc, "len: ", len(r_arr), len(poynt_proc_arr)
                raise ValueError("file length contradicts array lengths")
            write_out_arr[start_index_r:end_index_r,0] = r_arr
            write_out_arr[start_index_r:end_index_r,1] = rot_arr
        fname_out = outdir + 'rot.' + '%05d' % img_num + '.d'
        np.savetxt(fname_out,write_out_arr)

def join_inj_surf(img_num):
    #Check if file from root processor exists. If not, skip this file.
    fname_chk = MPI_outdir + 'inj_sur.p' + '%05d' % 0 + "." + '%05d' % (file_mult*img_num) + '.d'
    if(os.path.isfile(fname_chk)):
        print "joining inj_sur " + str(img_num)
        write_out_arr = np.zeros([2*Nt])
        for pt in range(0,nproc_t):
            if(pt < nproc_t -1):
                Nt_proc = Nt/nproc_t
            else:
                Nt_proc = Nt_proc_max
            start_index_t = pt*(Nt/nproc_t)
            end_index_t = start_index_t + Nt_proc
            fname_in = MPI_outdir + 'inj_sur.p' + '%05d' % pt + "." + '%05d' % (file_mult*img_num) + '.d'
            [qsig_arr,ninj_arr] = read_inj(img_num,fname_in=fname_in)
            if(Nt_proc != len(ninj_arr)):
                print "Nt_proc: ", Nt_proc, "len: ", ninj_arr
                raise ValueError("file length contradicts array lengths")
            write_out_arr[start_index_t:end_index_t] = qsig_arr
            write_out_arr[Nt+start_index_t:Nt+end_index_t] = ninj_arr
        fname_out = outdir + 'inj_sur.' + '%05d' % img_num + '.d'
        np.savetxt(fname_out,write_out_arr)

for img_num in range(start_img_num,end_img_num,img_stride):
    if(do_join_fields):
        join_fields_n(img_num,6,"flds")
    if(do_join_fields_grid):
        join_fields_n(img_num,6,"flds_grd")
    if(do_join_prtls):
        join_prtls(img_num,"prtl")
    if(do_join_tracers):
        join_prtls(img_num,"trcr")
    if(do_join_currents):
        join_fields_n(img_num,3,"cur")
    if(do_join_inj_vol and img_num !=0):
        join_fields_n(img_num,2,"inj_vol")
    if(do_join_inj_surf and img_num !=0):
        join_inj_surf(img_num)
    if(do_join_ptlg):
        join_fields_n(img_num,2,"ptlg")
    if(do_join_ptlv2):
        join_fields_n(img_num,6,"ptlv2")
    if(do_join_ptlq):
        join_fields_n(img_num,2,"ptlq")
    if(do_join_ptlj):
        join_fields_n(img_num,6,"ptlj")
    if(do_join_poynt):
        join_poynting(img_num)
    if(do_join_rot and nproc_r > 1):
        join_rot(img_num)
