import numpy as np
import matplotlib.pyplot as plt
import sys
import random
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
import pickle
from sim_pars import *
from math import pi
from trajectory_utils import *
from common import plot_light_cylinder, draw_pulsar

min_gamma = 500
min_radius = rs/Omega_rs_c
cyl_min_radius = .75*rs/Omega_rs_c
r_frac = .75
gamma_bool = False
radius_bool = True
cyl_radius_bool = False
radius_reverse_bool = False
prob_min = .1
resample = True

plot_lc = True
draw_psr = True
plot_fls = True
rescale = 1.
if(plot_lc):
    rlc = rs/Omega_rs_c
    rescale = 1./rlc
    xlim = 4.
else:
    rescale = 1./rs
    xlim = 2.*rs/Omega_rs_c*rescale
ylim = 1.
if(plot_fls):
    from file_reading import read_fields_from_file
    from field_lines import plot_field_lines
    fline_rmax = 1.5*xlim/rescale
    fline_rmin = rs

def resample_weight(R,z):
    prob = min(1./abs(R/np.sqrt(R**2+z**2)),1./prob_min)
    if(prob > random.random()/prob_min or not resample):
        return True
    else:
        return False
    
def make_plot(traj_dict,lc,rescale=1.):
    for n, key in enumerate(traj_dict):
        r_arr = np.sqrt(traj_dict[key]['x']**2+traj_dict[key]['y']**2)
        z_arr = traj_dict[key]['z']
        if(resample_weight(r_arr[0],z_arr[0]) \
           and gamma_condition(traj_dict,key,min_gamma,gamma_bool) \
           and radius_condition(traj_dict,key,min_radius,radius_bool) \
           and cyl_radius_condition(traj_dict,key,cyl_min_radius,cyl_radius_bool) \
           and radius_reverse_condition(traj_dict,key,r_frac,radius_reverse_bool)):
            plt.plot(r_arr*rescale, z_arr*rescale, lc)
    plt.draw()
    
#create dictionary by which to sift particles
traj_i_dict = pickle.load(open(indir+"traj_i.p","r"))
print "loaded positive charges"
traj_e_dict = pickle.load(open(indir+"traj_e.p","r"))
print "loaded negative charges"

plt.ion()
plt.axes().set_aspect('equal')
plt.xlim(0,xlim)
plt.ylim(-ylim,ylim)
make_plot(traj_i_dict,'red',rescale=rescale)
make_plot(traj_e_dict,'blue',rescale=rescale)
if(draw_psr):
    draw_pulsar(rescale=rescale)
    if(plot_lc):
        plt.xlabel(r"$R/R_{lc}$",fontsize=16)
        plt.ylabel(r"$z/R_{lc}$",fontsize=16)
        plot_light_cylinder(1,ylim)
    else:
        plt.xlabel(r"$R/R_0$",fontsize=16)
        plt.ylabel(r"$z/R_0$",fontsize=16)
if(plot_fls):
    img_num = 10
    [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
    fields = [br_arr.T,bt_arr.T]
    plot_field_lines(fields,[fline_rmin,fline_rmax],rescale=rescale)
#plt.savefig('trajectories_'+ '%05d' % img_num +'.png',bbox_inches='tight')
raw_input("press enter to advance")
plt.clf()
