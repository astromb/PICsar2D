import numpy as np
import matplotlib.pyplot as plt
from sim_pars import *
from file_reading import read_fields_from_file
from math import pi
from common import init_rt

plt.ion()
ymin = -.1
ymax = 1.1
img_num = 120

rescale = 1./rs
j = (Nt-1)/2
#j=0

[r_arr,rD_arr,th_arr,thD_arr] = init_rt()

[ex_arr,ey_arr,ez_arr,bx_arr,by_arr,bz_arr] = read_fields_from_file(img_num)
ex_arr *= 4*pi*rs**2
exmid_arr = ex_arr[j,:]
p1, = plt.plot(rD_arr*rescale,-exmid_arr,color='black',linewidth=2)
p2, = plt.plot(rD_arr*rescale,(rs/rD_arr)**(2.),color = 'red', linestyle = 'dashed',linewidth=2)
plt.ylim(ymin,ymax)
plt.xlabel("radial position ($R/R_0$)",fontsize=14)
plt.ylabel("radial component of electric field",fontsize=14)
plt.title("charged sphere comparison")
plt.legend([p1,p2], ["data", "analytic (1/r^2)"])
plt.draw()
print img_num
#plt.savefig('inv_square.png',bbox_inches='tight')
raw_input("press enter to advance")
plt.clf()
