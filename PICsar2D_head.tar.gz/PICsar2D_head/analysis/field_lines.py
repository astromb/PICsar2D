import numpy as np
from math import pi, cos, sin, sqrt
import matplotlib.pyplot as plt
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from interpolation import interpol_field
from sim_pars import Nr,Nt,is_dipole,rs,fdsample

dl = 1.

def plot_field_lines(fields,r_min_max,rescale=1.):
    grid_offsets = [[0,.5/fdsample],[.5/fdsample,0]]
    grid_sizes = [[(Nr-1)/fdsample,(Nt-1)/fdsample],[(Nr-1)/fdsample,(Nt-1)/fdsample]]
    if(is_dipole):
        #p0_list = [np.array([rs,.1]), np.array([rs,.25]), np.array([rs,.38]),np.array([rs,.48]), np.array([rs,.55]), np.array([rs,.615]), np.array([rs,.67]), np.array([rs,.705]), np.array([rs,.79]), np.array([rs,.94]), np.array([rs,1.25])]
        p0_list = [np.array([rs,.1]), np.array([rs,.25]), np.array([rs,.39]),np.array([rs,.5]), np.array([rs,.57]), np.array([rs,.635]), np.array([rs,.68]), np.array([rs,.78]), np.array([rs,.94]), np.array([rs,1.25])]
        #p0_list = [np.array([rs,.15]), np.array([rs,.3]),  np.array([rs,.425]), np.array([rs,.55]), np.array([rs,.705]), np.array([rs,.94]), np.array([rs,1.25])]
    else:
        p0_list = [np.array([rs,pi/8]), np.array([rs,pi/4]), np.array([rs,3*pi/8]), np.array([rs,pi/2]), np.array([rs,5*pi/8]), np.array([rs,3*pi/4]), np.array([rs,7*pi/8])]
    for p0 in p0_list:
        plot_companion = plot_field_line(p0,fields,grid_offsets,grid_sizes,r_min_max,dl,rescale=rescale)
        if(plot_companion):
            plot_field_line(np.array([-p0[0],pi-p0[1]]),fields,grid_offsets,grid_sizes,r_min_max,dl,rescale=rescale)

def plot_field_line(p0,fields,grid_offsets,grid_sizes,r_min_max,dl,rescale=1.):
    [p_list,plot_companion] = generate_field_line(p0,fields,grid_offsets,grid_sizes,r_min_max,dl)
    x = np.zeros(len(p_list))
    y = np.zeros(len(p_list))
    for i,p in enumerate(p_list):
        x[i] = p[0]*sin(p[1])*rescale
        y[i] = p[0]*cos(p[1])*rescale
    plt.plot(x,y,color="black",linewidth=2.)
    return plot_companion

def generate_field_line(p,fields,grid_offsets,grid_sizes,r_min_max,dl):
    fline_rmin = r_min_max[0]
    fline_rmax = r_min_max[1]
    # s = +1 means draw field line in the direction of vectors
    # s = -1 means draw the field line in opposite direction of vectors
    if (p[0] < 0):
        p[0] = -p[0]
        s = -1
    else:
        s = 1
    #p_list is list of points making up the field line
    p_list = [p]
    n = 0
    while(p[0] >= fline_rmin and p[0] <= fline_rmax):
        p = second_order_step(p,fields,grid_offsets,grid_sizes,s,dl)
        p_list.append(p)
    if(len(p_list) >= 2):
        p0 = p_list[-2]
        if (p[0] > fline_rmax):
            rc = fline_rmax
        else:
            rc = fline_rmin
        dr = (p[0]-rc)/(p[0]-p0[0])
        p_list[-1] = (1-dr)*p + dr*p0
    if(p[0] > fline_rmax):
        plot_companion = True
    else:
        plot_companion = False
    return [p_list, plot_companion]

#second order Runge Kutta step along field line
def second_order_step(p0,fields,grid_offsets,grid_sizes,s,dl):
    v0 = s*interpol_fields(p0,fields,grid_offsets,grid_sizes)
    v0 /= sqrt(v0[0]**2+v0[1]**2)
    v0[1] /= p0[0] #divide by the radius since we are working in theta
    p1 = p0+.5*dl*v0
    v1 = s*interpol_fields(p1,fields,grid_offsets,grid_sizes)
    v1 /= sqrt(v1[0]**2+v1[1]**2)
    v1[1] /= p1[0]
    return p0 + dl*v1

def interpol_fields(p0,fields,grid_offsets,grid_sizes):
    vi = interpol_field(p0,fields[0],grid_offsets[0],grid_sizes[0])
    vj = interpol_field(p0,fields[1],grid_offsets[1],grid_sizes[1])
    return np.array([vi,vj])
"""
def generate_dipole_fields():
    br_field = np.zeros([Nr,Nt])
    bt_field = np.zeros([Nr,Nt])
    for i in range(Nr):
        for j in range(Nt):
            pspher = grid2spher(i,j)
            r = pspher[0]
            th = pspher[1]
            br_field[i,j] = 2*rs**3/r**3*cos(th)
            bt_field[i,j] = rs**3/r**3*sin(th)
    return [br_field,bt_field]"""