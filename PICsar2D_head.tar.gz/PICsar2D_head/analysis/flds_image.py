import numpy as np
import matplotlib.pyplot as plt
import time
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from file_reading import read_fields_from_file, read_currents_from_file
from common import init_rt
from math import pi
from scipy import ndimage
import plot_trajectory as pt
from field_lines import plot_field_lines
from common import init_rt, plot_light_cylinder, draw_pulsar

fields = False
currents = True
vmin = -1.
vmax = 1.

plot_colorbar = True
plot_lc = True
draw_psr = True
plot_fls = True
plot_trajectory = True
if(plot_trajectory):
    traj_type = "ion"
    #p_keys_list = [(2172,352620),(2386,351810)]
    p_keys_list = None
    cmap = 'gray_r'
else:
    cmap = 'RdBu_r' #'spectral'
    
nfilt = 0

[r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)

rescale = 1.
if(plot_lc):
    rlc = rs/Omega_rs_c
    rescale = 1./rlc
    xlim = 3.
else:
    rescale = 1./rs
    xlim = r_arr[-1]*rescale
ylim = xlim/2.

if(plot_fls):
    from field_lines import plot_field_lines
    fline_rmax = min(1.5*xlim/rescale,r_arr[-1-Nlossy])
    fline_rmin = rs

plt.ion()
start_img_num = 10
end_img_num = 1000
img_stride = 1

for img_num in range(start_img_num,end_img_num+1,img_stride):
    if(fields or plot_fls):
        [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
        if(fields):
            B2 = br_arr*br_arr+bt_arr*bt_arr+bp_arr*bp_arr
            E2 = er_arr*er_arr+et_arr*et_arr+ep_arr*ep_arr
            Z = (B2-E2)/B2
            #Z = er_arr*(rD_arr/rs)**2
            #Z=(er_arr*br_arr+et_arr*bt_arr+ep_arr*bp_arr)/(E2**.5*B2**.5)
            #Z = abs(bp_arr)/np.sqrt(bt_arr**2+br_arr**2)
            #Z = bp_arr*(r_arr/rs)
            #Z=(et_arr*bp_arr-ep_arr*bt_arr)*(rD_arr*rD_arr)/(4*pi*(rs*B0*Omega_rs_c**2)**2)
            #Z=(et_arr*bp_arr-ep_arr*bt_arr)*(rD_arr*rD_arr)/(8*pi/3*(rs*B0*Omega_rs_c)**2)
    if(currents):
        [jr_arr,jt_arr,jp_arr] = read_currents_from_file(img_num)
        #normalization constant for the current (J_norm = c*rho_GJ*(rs/r)**2 at r=R_lc at the pole)
        if(is_dipole):
            J_norm = (2*2*B0*rs*c*Omega_rs_c**2)/(rD_arr*rD_arr) #polar field at star is 2*B0
        else:
            J_norm = (2*B0*rs*c*Omega_rs_c)/(rD_arr*rD_arr)
        Z = (jr_arr/(abs(jr_arr)+.0000001))*((jr_arr**2+jt_arr**2)**.5)/J_norm
        #J2 = jr_arr*jr_arr+jt_arr*jt_arr+jp_arr*jp_arr
        #Z = (er_arr*jr_arr+et_arr*jt_arr+ep_arr*jp_arr)/(E2**.5*J2**.5)

    print Z.max(), Z.min(),np.unravel_index(Z.argmax(),Z.shape),np.unravel_index(Z.argmin(),Z.shape), Z.shape
    
    plt.ylim(-ylim,ylim)
    plt.xlim(0,xlim)
    plt.axes().set_aspect('equal')
    rad,theta = np.meshgrid(rD_arr,th_arr)
    xx = rad*np.sin(theta)*rescale
    zz = rad*np.cos(theta)*rescale
    plt.pcolormesh(xx,zz,Z,vmin=vmin,vmax=vmax,cmap=cmap)

    if(plot_colorbar):
        plt.colorbar()
    if(draw_psr):
        draw_pulsar(rescale=rescale)
    if(plot_lc):
        plt.xlabel(r"$R/R_{lc}$",fontsize=16)
        plt.ylabel(r"$z/R_{lc}$",fontsize=16)
        plot_light_cylinder(1,ylim)
    else:
        plt.xlabel(r"$R/R_0$",fontsize=16)
        plt.ylabel(r"$z/R_0$",fontsize=16)
    if(plot_fls):
        [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
        fields = [br_arr.T,bt_arr.T]
        plot_field_lines(fields,[fline_rmin,fline_rmax],rescale=rescale)
    if(plot_trajectory):
        pt.plot_trajectory(traj_type,rescale=rescale,xmax=xlim,ymax=ylim,keys_list=p_keys_list,gamma_color_lim=[1.,20000.])
    #plt.savefig('cur_traj_ion'+ '%05d' % img_num +'.png',bbox_inches='tight')
    raw_input("press enter to advance")
    plt.clf()
