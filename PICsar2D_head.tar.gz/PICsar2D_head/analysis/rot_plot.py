import numpy as np
import matplotlib.pyplot as plt
import time
from math import pi
from pylab import savefig
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from file_reading import read_rot
from common import convert_fnum_to_time

plt.ion()
rmax = 3.*rs
rlc = rs*c/Omega_rs_c
start_img_num = 10
end_img_num = 1000
img_stride = 1
for img_num in range(start_img_num,end_img_num+1, img_stride):
    [r_arr,data_arr] = read_rot(img_num)
    [r_arr,data_arr0] = read_rot(0)
    r_arr /= rs
    data_arr /= Omega_rs_c
    data_arr0 /= Omega_rs_c
    p1, = plt.plot(r_arr,data_arr, color="black", linewidth=2.)
    p2, = plt.plot(r_arr,data_arr0, color="black", linewidth=2., linestyle="--")
    plt.xlabel("cyl. radius $R/r_*$",fontsize=18)
    plt.ylabel("$\Omega/\Omega_*$  at equator",fontsize=18)
    plt.tick_params(labelsize=16)
    plt.xlim(1,rmax/rs)
    plt.ylim(0.,2.)
    plt.draw()
    #plt.title('time (periods) = ' + convert_fnum_to_time(img_num),fontsize=20)
    plt.legend([p1,p2],["simulation","vacuum"],loc=1,frameon=True,fontsize=16)
    #plt.savefig('rot_prof_mode0_'+ '%05d' % img_num +'.png',bbox_inches='tight')
    raw_input("press enter to advance")
    plt.clf()
    