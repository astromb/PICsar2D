import numpy as np
import matplotlib.pyplot as plt
import time
from math import pi, atan2
from common import P_VX4, P_VY4, P_X, P_Y, draw_pulsar
from sim_pars import *

plot_type = 'xy'

rescale = 1./rs
vp_arr = np.zeros(end_img_num-start_img_num+1)
x_arr = np.zeros(end_img_num-start_img_num+1)
y_arr = np.zeros(end_img_num-start_img_num+1)
phi_arr = np.zeros(end_img_num-start_img_num+1)
t_arr = np.zeros(end_img_num-start_img_num+1)
r_arr = np.zeros(end_img_num-start_img_num+1)
plt.ion()
for img_num in range(start_img_num,end_img_num+1):
    fname = '../output/prtl.' + '%05d' % img_num + '.d'
    f = open(fname,'r')
    lines = f.readlines()
    f.close()
    l0 = lines[0].split()
    n_ions = int(l0[0])
    n_lecs = int(l0[1])
    p1 = lines[n_ions].split()
    vp_arr[img_num-start_img_num] = (float(p1[P_VX4])**2+float(p1[P_VY4])**2)**.5/(c*c+float(p1[P_VX4])**2+float(p1[P_VY4])**2)**.5
    t_arr[img_num-start_img_num] = img_num*write_stride/(2*pi*rs/(Omega_rs_c*c))
    x_arr[img_num-start_img_num] = float(p1[P_X])*rescale
    y_arr[img_num-start_img_num] = float(p1[P_Y])*rescale
    phi_arr[img_num-start_img_num] = atan2(float(p1[P_Y]),float(p1[P_X]))
    r_arr[img_num-start_img_num] = np.sqrt(float(p1[P_X])**2 + float(p1[P_Y])**2)*rescale

if(plot_type == 'xy'):
    plt.plot(x_arr,y_arr,linewidth=2, color='black')
    draw_pulsar(rescale=rescale,plot_xy=True)
    plt.axis("equal")
    plt.xlim(-4,4)
    plt.ylim(-4,4)
    plt.xlabel("x position ($x/R_0$)",fontsize=16)
    plt.ylabel("y position ($y/R_0$)",fontsize=16)
elif(plot_type == 'vphi'):
    plt.plot(t_arr,vp_arr,linewidth=2, color='black')
    #plt.ylim(0,1)
    plt.ylabel("$V_\phi/c$",fontsize=16)
    plt.xlabel("time (periods)",fontsize=16)
elif(plot_type == 'rad'):
    plt.plot(t_arr,r_arr,linewidth=2, color='black')
    plt.ylabel("cylindrical radius ($R/R_0$)",fontsize=16)
    plt.xlabel("time (periods)",fontsize=16)
else:
    raise ValueError("no such plot type in prtl_plot")

plt.show()
#print "V_phi_sim/V_phi_anal: ", np.mean(vp_arr)/(r0*Omega_rs_c/rs)
print "V_phi_sim/V_phi_anal: ", r0*(2*pi+phi_arr[-1]-phi_arr[0])/(Nstep*c*r0*Omega_rs_c/rs)
#plt.savefig('prtl_plot.png',bbox_inches='tight')
raw_input("press enter to advance")
