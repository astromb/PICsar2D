import numpy as np
import matplotlib.pyplot as plt
import time
from math import pi
from file_reading import read_fields_from_file, read_currents_from_file
from common import init_rt, plot_light_cylinder, draw_pulsar, calc_grid_size_r, calc_grid_size_t
from sim_pars import *
from calc_div import calc_div_arr
from scipy import ndimage

#if calc_E_div is true electric calc divE else calc divB
divE = True
true_div = True
plot_colorbar = True
plot_lc = True
draw_psr = True
plot_fls = False
nfilt = 0

plt.ion()
[r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)
start_img_num = 10
end_img_num = 300
img_stride = 1
rmax = r_arr[-1]
if(plot_lc):
    rescale = Omega_rs_c/rs
    xlim = 3.
else:
    rescale = 1./rs
    xlim = r_arr[-1]*rescale
ylim = xlim/2

if(plot_fls):
    from field_lines import plot_field_lines
    fline_rmax = min(1.5*xlim/rescale,r_arr[-1-Nlossy])
    fline_rmin = rs

Nrg = (Nr-1+fdsample)/fdsample
Ntg = (Nt-1+fdsample)/fdsample
div_arr = np.zeros( (Nrg,Ntg) )

th_mid = np.zeros(len(th_arr))
th_mid[0] = 0
th_mid[len(th_arr)-1] = pi
for i in range(1,len(th_arr)-1):
    th_mid[i] = (thD_arr[i-1]+thD_arr[i])/2.

rad,theta = np.meshgrid(rD_arr,th_mid)
xx = rad*np.sin(theta)*rescale
zz = rad*np.cos(theta)*rescale
xx = xx[:,Nghost_r+1:Nrg-Nghost_r-Nlossy-1]
zz = zz[:,Nghost_r+1:Nrg-Nghost_r-Nlossy-1]

for img_num in range(start_img_num,end_img_num+1,img_stride):
    div_arr = calc_div_arr(img_num, divE, True)
    
    [jx_arr,jy_arr,jz_arr] = read_currents_from_file(img_num)
    Z = ((c*div_arr.T)**2-(jx_arr)**2-(jy_arr)**2-(jz_arr)**2)/(c*div_arr.T)**2
    Z = Z[:,Nghost_r+1:Nrg-Nghost_r-Nlossy-1]
    #optional filtering of the solution (wrap around boundaries)
    for n in range(0,nfilt):
        Z = ndimage.gaussian_filter(Z,1,mode="wrap")
    
    plt.ylim(-ylim,ylim)
    plt.xlim(0,xlim)
    plt.axes().set_aspect('equal')

    plt.pcolormesh(xx,zz,Z,cmap='RdBu_r',vmin=-2.,vmax=2.)

    if(draw_psr):
        draw_pulsar(rescale=rescale)
    if(plot_colorbar):
        plt.colorbar()
    if(plot_lc):
        plt.xlabel(r"$R/R_{lc}$",fontsize=16)
        plt.ylabel(r"$z/R_{lc}$",fontsize=16)
        plot_light_cylinder(1,ylim)
    else:
        plt.xlabel(r"$R/R_0$",fontsize=16)
        plt.ylabel(r"$z/R_0$",fontsize=16)
    if(plot_fls):
        plot_field_lines([br_arr.T,bt_arr.T],[fline_rmin,fline_rmax],rescale=rescale)

        
    plt.draw()
    #plt.savefig('J4.' + '%05d' % (img_num) + '.png',bbox_inches='tight')
    print img_num
    raw_input("press enter to advance")
    plt.clf()
