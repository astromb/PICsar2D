import numpy as np
import matplotlib.pyplot as plt
import time
from math import pi
from file_reading import read_fields_from_file, read_currents_from_file
from common import init_rt, plot_light_cylinder, draw_pulsar, calc_grid_size_r, calc_grid_size_t
from sim_pars import *

def calc_r_flux(vr,r,th1,th2):
    return vr*2*pi*(np.cos(th1)-np.cos(th2))*r*r

def calc_t_flux(vt,r1,r2,th):
    return vt*pi*(r2*r2-r1*r1)*np.sin(th)

def vol(r1,r2,th1,th2):
    return 2*pi/3.*(r2**3-r1**3)*(np.cos(th1)-np.cos(th2))

def calc_div_arr(img_num, calc_divE, true_div):
    [r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)
    [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num,fld_type="flds_grd")
    Nrg = calc_grid_size_r()
    Ntg = calc_grid_size_t()
    div_arr = np.zeros( (Nrg,Ntg) )
    if(calc_divE):
        #calculate divergence throughout the simulation
        for i in range(1, Nrg-1):
            for j in range(1,Ntg-1):
                Er0_flux = calc_r_flux(er_arr[j,i-1],rD_arr[i-1],thD_arr[j-1],thD_arr[j])
                Er1_flux = calc_r_flux(er_arr[j,i],rD_arr[i],thD_arr[j-1],thD_arr[j])
                Et0_flux = calc_t_flux(et_arr[j-1,i],rD_arr[i-1],rD_arr[i],thD_arr[j-1])
                Et1_flux = calc_t_flux(et_arr[j,i],rD_arr[i-1],rD_arr[i],thD_arr[j])
                div_arr[i,j] = (Er1_flux-Er0_flux+Et1_flux-Et0_flux)
                if(true_div):
                    div_arr[i,j] /= vol(rD_arr[i-1],rD_arr[i],thD_arr[j-1],thD_arr[j])
                    
        #calculate the divergence on the poles
        for i in range(1, Nrg-1):
            Er0_flux = calc_r_flux(er_arr[0,i-1],rD_arr[i-1],0.,thD_arr[0])
            Er1_flux = calc_r_flux(er_arr[0,i],rD_arr[i],0.,thD_arr[0])
            Et0_flux = 0
            Et1_flux = calc_t_flux(et_arr[0,i],rD_arr[i-1],rD_arr[i],thD_arr[0])
            div_arr[i,0] = Er1_flux-Er0_flux+Et1_flux-Et0_flux
            if(true_div):
                div_arr[i,0] /= vol(rD_arr[i-1],rD_arr[i],0,thD_arr[0])
    
        #calculate the divergence on the poles
        for i in range(1, Nrg-1):
            Er0_flux = calc_r_flux(er_arr[Ntg-1,i-1],rD_arr[i-1],thD_arr[Ntg-2],pi)
            Er1_flux = calc_r_flux(er_arr[Ntg-1,i],rD_arr[i],thD_arr[Ntg-2],pi)
            Et0_flux = calc_t_flux(et_arr[Ntg-2,i],rD_arr[i-1],rD_arr[i],thD_arr[Ntg-2])
            Et1_flux = 0
            div_arr[i,Ntg-1] = Er1_flux-Er0_flux+Et1_flux-Et0_flux
            if(true_div):
                div_arr[i,Ntg-1] /= vol(rD_arr[i-1],rD_arr[i],thD_arr[Ntg-2],pi)
        print vol(rD_arr[i-1],rD_arr[i],thD_arr[Ntg-2],pi), vol(rD_arr[i-1],rD_arr[i],0,thD_arr[0])
        print pi-thD_arr[Ntg-2], thD_arr[1]
    else:
        #calculate divergence throughout the simulation
        for i in range(0, Nrg-2):
            for j in range(0,Ntg-1):
                Br0_flux = calc_r_flux(br_arr[j,i],r_arr[i],th_arr[j],th_arr[j+1])
                Br1_flux = calc_r_flux(br_arr[j,i+1],r_arr[i+1],th_arr[j],th_arr[j+1])
                Bt0_flux = calc_t_flux(bt_arr[j,i],r_arr[i],r_arr[i+1],th_arr[j])
                Bt1_flux = calc_t_flux(bt_arr[j+1,i],r_arr[i],r_arr[i+1],th_arr[j+1])
                div_arr[i,j] = Br1_flux-Br0_flux+Bt1_flux-Bt0_flux
                if(true_div):
                    div_arr[i,j] /= vol(r_arr[i],rD_arr[i+1],thD_arr[j],thD_arr[j+1])
    return div_arr

def div_image():
    #if calc_E_div is true electric calc divE else calc divB
    divE = True
    true_div = True
    plot_colorbar = True
    draw_psr = True
    plot_lc = True
    try:
        plot_lc
    except :
        plot_lc = False

    try:
        plot_fls
    except:
        plot_fls = False
    
    plt.ion()
    [r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)
    start_img_num = 0
    end_img_num = 300
    img_stride = 1
    rmax = r_arr[-1]
    if(plot_lc):
        rescale = Omega_rs_c/rs
        xlim = 3
    else:
        rescale = 1./rs
        xlim = r_arr[-1]*rescale
    ylim = xlim
    
    if(plot_fls):
        from field_lines import plot_field_lines
        fline_rmax = min(1.5*xlim/rescale,r_arr[-1-Nlossy])
        fline_rmin = rs
    
    Nrg = calc_grid_size_r()
    Ntg = calc_grid_size_t()
    
    th_mid = np.zeros(len(th_arr))
    th_mid[0] = 0
    th_mid[len(th_arr)-1] = pi
    for i in range(1,len(th_arr)-1):
        th_mid[i] = (thD_arr[i-1]+thD_arr[i])/2.
    
    rad,theta = np.meshgrid(rD_arr,th_mid)
    xx = rad*np.sin(theta)*rescale
    zz = rad*np.cos(theta)*rescale
    xx = xx[:,Nghost_r+1:Nrg-Nghost_r-Nlossy-1]
    zz = zz[:,Nghost_r+1:Nrg-Nghost_r-Nlossy-1]
    
    for img_num in range(start_img_num,end_img_num+1,img_stride):
        div_arr = calc_div_arr(img_num, divE, True)
        
        #[jx_arr,jy_arr,jz_arr] = read_currents_from_file(img_num)
        #Z = ((c*div_arr.T)**2-(jx_arr)**2-(jy_arr)**2-(jz_arr)**2)/(c*div_arr.T)**2
        #Z = ((c*div_arr.T)**2-(jx_arr)**2-(jy_arr)**2-(jz_arr)**2)*(rD_arr*rD_arr/(B0*rs*c*Omega_rs_c))**2
        Z = (div_arr.T)*rD_arr*rD_arr/(rs*rs)
        Z = Z[:,Nghost_r+1:Nrg-Nghost_r-Nlossy-1]
        print Z.max(), Z.min(),np.unravel_index(Z.argmax(),Z.shape),np.unravel_index(Z.argmin(),Z.shape), Z.shape
        #Z=Z.T
        plt.ylim(-ylim,ylim)
        plt.xlim(0,xlim)
        plt.axes().set_aspect('equal')
        #plt.plot(Z[:,128])
    
        plt.pcolormesh(xx,zz,Z,cmap='RdBu_r')#,vmin=-.05,vmax=.05)
        #plt.pcolormesh(xx,zz,Z,vmin=-1,vmax=1)
        #plt.imshow(Z[:,:128],origin='lower',vmin=0,vmax=2)
    
        if(draw_psr):
            draw_pulsar(rescale=rescale)
        if(plot_colorbar):
            plt.colorbar()
        if(plot_lc):
            plt.xlabel(r"$R/R_{lc}$",fontsize=16)
            plt.ylabel(r"$z/R_{lc}$",fontsize=16)
            plot_light_cylinder(1,ylim)
        else:
            plt.xlabel(r"$R/R_0$",fontsize=16)
            plt.ylabel(r"$z/R_0$",fontsize=16)
        if(plot_fls):
            plot_field_lines([br_arr.T,bt_arr.T],[fline_rmin,fline_rmax],rescale=rescale)

        plt.draw()
        #plt.savefig('div.' + '%05d' % (img_num) + '.png',bbox_inches='tight')
        print img_num
        raw_input("press enter to advance")
        plt.clf()
    
if __name__ == "__main__":
    div_image()
