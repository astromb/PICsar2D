is_dipole = False
write_ghost = False
Nlossy = 10
#simulation parameters
equal_area_theta = True
logarithmic_r = True
if(is_dipole):
    indir = "../output/"
    #physical constants
    c = .6
    #physical parameters
    Omega_rs_c = .25
    scfc = 1
    rs = 64*scfc
    B0 = 16000./scfc #B field at surface of star in midplane
    qi = 10000./scfc
    qe = -qi
    #simulation parameters
    Nfilt = 2
    if(write_ghost):
        Nghost_r = 4+Nfilt
        Nghost_t = 4+Nfilt
    else:
        Nghost_r = 0
        Nghost_t = 0
    Nlossy = 10
    Nr = 4*64*scfc+1
    if(equal_area_theta):
        Nt = 2*64*scfc+1
    else:
        Nt = 3*64*scfc+1
    #write to file parameters
    start_write = 0
    write_stride = 1000*scfc
    #MPI parameters
    nproc_r = 2
    nproc_t = 2
    fdsample=1
else:
    indir = "../output/"
    #physical constants
    c = .6
    scfc = 1
    #physical parameters
    rs = 64*scfc
    B0 = 16000./scfc
    qi = 500./scfc
    Omega_rs_c = .2
    #simulation parameters
    Nfilt = 2
    if(write_ghost):
        Nghost_r = 4+Nfilt
        Nghost_t = 4+Nfilt
    else:
        Nghost_r = 0
        Nghost_t = 0
    Nr = 4*rs+1
    Nt = 2*rs+1
    #write to file parameters
    start_write = 0
    write_stride = 1000*scfc
    #MPI parameters
    nproc_r = 1
    nproc_t = 1
    fdsample=1
Nt_proc_max = Nt - (nproc_t-1)*(Nt/nproc_t)
Nr_proc_max = Nr - (nproc_r-1)*(Nr/nproc_r)
