import numpy as np
def gamma_condition(traj_dict,key,min_gamma,gamma_bool):
    gamma_arr = np.sqrt(1 + traj_dict[key]['vx4']**2+traj_dict[key]['vy4']**2+traj_dict[key]['vz4']**2)
    if(max(gamma_arr) > min_gamma or not gamma_bool):
        return True
    else:
        return False

def radius_condition(traj_dict,key,min_radius,radius_bool):
    rad_arr = np.sqrt(traj_dict[key]['x']**2+traj_dict[key]['y']**2+traj_dict[key]['z']**2)
    if(max(rad_arr) > min_radius or not radius_bool):
        return True
    else:
        return False
    
def cyl_radius_condition(traj_dict,key,min_radius,radius_bool):
    rad_arr = np.sqrt(traj_dict[key]['x']**2+traj_dict[key]['y']**2)
    if(max(rad_arr) > min_radius or not radius_bool):
        return True
    else:
        return False
    
def radius_reverse_condition(traj_dict,key,r_frac,radius_reverse_bool):
    rad_arr = np.sqrt(traj_dict[key]['x']**2+traj_dict[key]['y']**2+traj_dict[key]['z']**2) 
    if(rad_arr[-1] < r_frac*max(rad_arr) or not radius_reverse_bool):
        return True
    else:
        return False