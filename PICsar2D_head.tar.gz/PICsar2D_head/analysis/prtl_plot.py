import numpy as np
import matplotlib.pyplot as plt
import time
from pylab import savefig
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from math import pi
from common import init_rt, plot_light_cylinder, draw_pulsar, vol
from file_reading import read_fields_from_file, read_prtl_dens, read_fields
from scipy import ndimage

plot_type = "ptlq"

plot_colorbar = True
plot_lc = True
draw_psr = True
plot_fls = True
nfilt = 0

[r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)

rescale = 1.
if(plot_lc):
    rlc = rs/Omega_rs_c
    rescale = 1./rlc
    xlim = 2.
else:
    rescale = 1./rs
    xlim = r_arr[-1]*rescale
ylim = xlim/2

if(plot_fls):
    from field_lines import plot_field_lines
    fline_rmax = min(1.5*xlim/rescale,r_arr[-1-Nlossy])
    fline_rmin = rs

plt.ion()
start_img_num = 10
end_img_num = 1000
img_stride = 1

for img_num in range(start_img_num,end_img_num+1,img_stride):
    print img_num
    if(plot_type == "ptlg"): #average particle gamma factor in a cell
        fname = indir +'/ptlg.' + '%05d' % img_num + '.d'
        [gion_arr,glec_arr] = read_prtl_dens(img_num,fname)
        #optional filtering of the solution (wrap around boundaries)
        for n in range(0,nfilt):
            gion_arr = ndimage.gaussian_filter(gion_arr,1,mode="wrap")
            glec_arr = ndimage.gaussian_filter(glec_arr,1,mode="wrap")
        data_arr = np.log10(gion_arr) #ion gamma factor
        #data_arr = glec_arr #electron gamma factor
    elif(plot_type == "ptlq"): #total charge in a cell
        fname = indir + '/ptlq.' + '%05d' % img_num + '.d'
        [qion_arr,qlec_arr] = read_prtl_dens(img_num,fname)
        #optional filtering of the solution (wrap around boundaries)
        for n in range(0,nfilt):
            qion_arr = ndimage.gaussian_filter(qion_arr,1,mode="wrap")
            qlec_arr = ndimage.gaussian_filter(qlec_arr,1,mode="wrap")
        #data_arr = np.log10(qion_arr/qi) #log ions per cell
        #data_arr = np.log10(qlec_arr/qe) #log lecs per cell
        data_arr = np.log10(qion_arr/qi+qlec_arr/qe) #log ppc
        #data_arr = abs((qlec_arr-qion_arr)/(qion_arr+qlec_arr)) #pair multiplicity
    elif(plot_type == "ptlj"): #current density due to particles
        fname = indir +'/ptlj.' + '%05d' % img_num + '.d'
        [jri_arr,jre_arr,jti_arr,jte_arr,jpi_arr,jpe_arr] = read_fields(fname,6)
        #optional filtering of the solution (wrap around boundaries)
        for n in range(0,nfilt):
            jri_arr = ndimage.gaussian_filter(jri_arr,1,mode="wrap")
            jre_arr = ndimage.gaussian_filter(jre_arr,1,mode="wrap")
            jti_arr = ndimage.gaussian_filter(jti_arr,1,mode="wrap")
            jte_arr = ndimage.gaussian_filter(jte_arr,1,mode="wrap")
            jpi_arr = ndimage.gaussian_filter(jpi_arr,1,mode="wrap")
            jpe_arr = ndimage.gaussian_filter(jpe_arr,1,mode="wrap")
        jr_arr = jri_arr + jre_arr
        jt_arr = jti_arr + jte_arr
        #jr_arr = jri_arr
        #jt_arr = jti_arr
        #poloidal current magnitude with the sign of the radial current
        data_arr = (jr_arr/(abs(jr_arr)+.0000001))*((jr_arr**2+jt_arr**2)**.5)
        #divide by the cell volume to get the current density
        for i in range(0,len(rD_arr)):
            for j in range(0,len(thD_arr)):
                data_arr[j,i] = data_arr[j,i]/vol(i,j,rD_arr[i],thD_arr[j])
        
        #normalization constant for the current (J_norm = c*rho_GJ*(rs/r)**2 at r=R_lc at the pole)
        if(is_dipole):
            J_norm = (2*2*B0*rs*c*Omega_rs_c**2)/(rD_arr*rD_arr) #polar field at star is 2*B0
        else:
            J_norm = (2*B0*rs*c*Omega_rs_c)/(rD_arr*rD_arr)
        
        data_arr /= J_norm
    else:
        print "error in prtl_dens_plot: no such plot type"
    
    plt.xlim(0,xlim)
    plt.ylim(-ylim,ylim)
    plt.axes().set_aspect('equal')
    rad,theta = np.meshgrid(rD_arr,th_arr)
    xx = rad*np.sin(theta)*rescale
    zz = rad*np.cos(theta)*rescale
    if(plot_type == "ptlg"):
        vmin = 0.
        vmax = 4.
        cmap='spectral'
    elif(plot_type == "ptlq"):
        vmin = 0.
        vmax = 3.
        #vmax=10.
        cmap='spectral'
    elif(plot_type == "ptlj"):
        vmin = -2.
        vmax = 2.
        cmap='RdBu_r'
        
    plt.pcolormesh(xx,zz,data_arr,vmin=vmin,vmax=vmax,cmap=cmap)

    if(plot_colorbar):
        plt.colorbar()
    if(draw_psr):
        draw_pulsar(rescale=rescale)
    if(plot_lc):
        plt.xlabel(r"$R/R_{lc}$",fontsize=16)
        plt.ylabel(r"$z/R_{lc}$",fontsize=16)
        plot_light_cylinder(1,ylim)
    else:
        plt.xlabel(r"$R/R_0$",fontsize=16)
        plt.ylabel(r"$z/R_0$",fontsize=16)
    if(plot_fls):
        [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
        fields = [br_arr.T,bt_arr.T]
        plot_field_lines(fields,[fline_rmin,fline_rmax],rescale=rescale)
    #plt.savefig('gamma_mode4_'+ '%05d' % img_num +'.png',bbox_inches='tight')
    plt.draw()
    raw_input("press enter to advance")
    plt.clf()
    
