import numpy as np
from math import pi
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from math import log

def spher2grid(r,th):
    if(logarithmic_r):
        rg = rs*log(r/rs)
    else:
        rg = r - rs
    if(write_ghost):
        rg = rg + Nghost_r
    rg = rg/fdsample
    if(equal_area_theta):
#convert from spherical to theta_area to grid
        dth_A = 2./(Nt-1)
        th_A = -np.cos(th)
        thg = (th_A+1)/dth_A
    else:
        dth = pi/(Nt-1)
        thg = th/dth
    if(write_ghost):
        thg = thg + Nghost_t
    thg = thg/fdsample
    return np.array([rg,thg])

"""def grid2spher(rg,thg):
    r = rg + rs - Nghost_r
    if(equal_area_theta):
        dth_A = 2./(Nt-1)
        th_A = thg*dth_A-1
        th = np.arccos(-th_A) 
    else:
        dth = pi/(Nt-1)
        th = dth*thg
    return np.array([r,th])"""