from math import log
#simulation parameters
indir = "../output/"
Nghost_r = 0
Nghost_t = 0
write_ghost = False
Nlossy = 0
equal_area_theta = True
logarithmic_r = True
fac = 2
Nr=32*fac+1
Nt = 16*fac+1
ro_rs = (96.+27.0365096353)/27.0365096353
if(logarithmic_r):
    rs = (Nr-1)/log(ro_rs)
else:
    rs = (Nr-1)/(ro_rs-1)
k = .101481563523*27.0365096353/rs
#physical constants
c = .6
tt = int(3.*3.14159265359/(k*c))

#write to file parameters
start_write = 0
write_stride = tt
fdsample = 1

#MPI parameters
nproc_r = 1
nproc_t = 1
Nt_proc_max = Nt - (nproc_t-1)*(Nt/nproc_t)
Nr_proc_max = Nr - (nproc_r-1)*(Nr/nproc_r)