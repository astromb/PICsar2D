#simulation parameters
indir = "../output/"
equal_area_theta = True
logarithmic_r = False
#physical constants
c = .6
#physical parameters
rs = 32
#simulation parameters
Nfilt = 3
Nlossy = 12
Nghost_r = 0
Nghost_t = 0
Nr = 129
Nt = 65

#write to file parameters
start_write = 0
write_stride = 250*rs/64
fdsample = 1
write_ghost = 0

nproc_r = 1
nproc_t = 1
Nt_proc_max = Nt - (nproc_t-1)*(Nt/nproc_t)
Nr_proc_max = Nr - (nproc_r-1)*(Nr/nproc_r)