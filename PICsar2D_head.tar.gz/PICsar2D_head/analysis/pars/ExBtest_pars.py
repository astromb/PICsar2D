#simulation parameters
indir = "../output/"
equal_area_theta = True
logarithmic_r = True
#physical constants
c = .6
#physical parameters
rs = 128
#simulation parameters
Nfilt = 3
Nlossy = 10
Nghost_r = 4+Nfilt
Nghost_t = 4+Nfilt
Nr = 353
Nt = 257

r0 = 3*rs
Omega_rs_c = .25

#write to file parameters
start_img_num = 0
end_img_num = 500
write_stride = 10
Nstep = write_stride*end_img_num
fdsample = 1
write_ghost = False

nproc_r = 1
nproc_t = 1
Nt_proc_max = Nt - (nproc_t-1)*(Nt/nproc_t)
Nr_proc_max = Nr - (nproc_r-1)*(Nr/nproc_r)