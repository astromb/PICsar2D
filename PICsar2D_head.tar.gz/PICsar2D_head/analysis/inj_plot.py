import numpy as np
import matplotlib.pyplot as plt
import time
from math import pi
from pylab import savefig
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from common import init_rt, convert_fnum_to_time
from file_reading import read_inj

plt.ion()
start_img_num = 1
end_img_num = 3000
rlc = rs/Omega_rs_c
[r_arr,rD_arr,th_arr,thD_arr] = init_rt()
theta_arr = thD_arr[:-1]
should_plot_anal_arr = True
for img_num in range(start_img_num,end_img_num+1):
    print img_num
    [qsig_arr,ninj_arr] = read_inj(img_num)
    data_arr = qsig_arr[:-1]
    sf=1
    if(is_dipole):
        data_anal_arr = -B0*Omega_rs_c*sf*2*(np.cos(theta_arr))**2
    else: #monopole
        data_anal_arr = -B0*Omega_rs_c*sf*2*np.cos(theta_arr)
    if(should_plot_anal_arr):
        p1, = plt.plot(theta_arr,data_arr,linewidth=1.5,color='black')
        p2, = plt.plot(theta_arr,data_anal_arr,linewidth=1.5,linestyle='dashed',color='black')
        plt.legend([p1,p2], ["simulation", "vacuum"],loc=4,fontsize=16)
    else:
        data_arr = data_arr/np.amax(abs(data_anal_arr))
        plt.plot(theta_arr,data_arr,linewidth=1.5,color='black')
    plt.xlim([0,3.1416])
    plt.xlabel(r"$\theta$ (radians)",fontsize=16)
    plt.ylabel(r"surface charge fraction",fontsize=16)
    plt.xticks(np.array([0,pi/4,pi/2,3*pi/4,pi]),np.array([r"$0$",r"$\pi/4$",r"$\pi/2$",r"$3\pi/4$",r"$\pi$"]))
    plt.tick_params(labelsize=16,axis='x')
    plt.tick_params(labelsize=14,axis='y')
    #plt.text(0.05,1.25,'time (periods) = ' + convert_fnum_to_time(img_num,write_stride,start_write,c,rlc),fontsize=15)
#    plt.savefig('inj_surf.' + '%05d' % (img_num) + '.png',bbox_inches='tight')
    plt.draw()
    raw_input("press enter to advance")
    plt.clf()
    
