import numpy as np
import matplotlib.pyplot as plt
import time
import random
from math import pi,sqrt
from pylab import savefig
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from file_reading import read_prtl_triples_from_file, read_fields_from_file
from common import plot_light_cylinder, init_rt, draw_pulsar, convert_fnum_to_time

def pdsample_weighted(pdsample,x_arr,y_arr,z_arr):
    i = 0
    nprtl = len(x_arr)
    while(i < nprtl):
        prob = min(1./(pdsample*sqrt(x_arr[i]**2+y_arr[i]**2)/rs),1.)
        if(prob < random.random()):
            x_arr[i] = x_arr[nprtl-1]
            y_arr[i] = y_arr[nprtl-1]
            z_arr[i] = z_arr[nprtl-1]
            i -= 1
            nprtl -= 1
        i += 1
    return [x_arr[:nprtl], y_arr[:nprtl], z_arr[:nprtl]]

plot_fls = True
plot_lc = True
plot_ticks = False
draw_psr = True
pdsample_weight = False
draw_time = True
pdsample_weight_val = 10
plot_xy_plane = False
pdsample = 1

start_img_num = 10
end_img_num = 1000
img_stride = 1

[r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)
rescale = 1./rs
xlim =3.*rs*rescale
ylim = xlim
if(plot_fls):
    from field_lines import plot_field_lines
    fline_rmax = min(1.5*xlim/rescale,r_arr[-1-Nlossy])
    fline_rmin = rs
    
plt.ion()
#offsets of vector locations from grid point locations
data_arr = np.zeros(end_img_num-start_img_num+1)
for img_num in range(start_img_num,end_img_num+1,img_stride):
    [xi_arr,yi_arr,zi_arr,xe_arr,ye_arr,ze_arr] = read_prtl_triples_from_file(img_num,pdsample=pdsample,strt=0)
    if(pdsample_weight):
        [xi_arr,yi_arr,zi_arr] = pdsample_weighted(pdsample_weight_val,xi_arr,yi_arr,zi_arr)
        [xe_arr,ye_arr,ze_arr] = pdsample_weighted(pdsample_weight_val,xe_arr,ye_arr,ze_arr)
    xi_arr *= rescale
    xe_arr *= rescale
    yi_arr *= rescale
    ye_arr *= rescale
    zi_arr *= rescale
    ze_arr *= rescale
    if(plot_xy_plane):
        plt.scatter(xi_arr,yi_arr,color='red',s=1)        
        plt.scatter(xe_arr,ye_arr,color='blue',s=1)
    else:
        plt.scatter((xi_arr**2+yi_arr**2)**.5,zi_arr,color='red',s=4)
        plt.scatter((xe_arr**2+ye_arr**2)**.5,ze_arr,color='blue',s=4)
    if(plot_fls):
      [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
      fields = [br_arr.T,bt_arr.T]
      plot_field_lines(fields,[fline_rmin,fline_rmax],rescale=rescale)
    if(plot_lc):
        rlc = rs/Omega_rs_c
        plot_light_cylinder(rlc*rescale,ylim)
    if(draw_psr):
        draw_pulsar(rescale=rescale)
    if(draw_time):
        plt.title('time (periods) = ' + convert_fnum_to_time(img_num),fontsize=15)
    plt.xlim(0,xlim)
    plt.ylim(-ylim,ylim)
    plt.axes().set_aspect('equal')
    plt.xlabel("cyl. radius ($R/r_0$)",fontsize=16)
    plt.ylabel("z position ($z/r_0$)",fontsize=16)
    #plt.savefig('prtl_image_mode0_.' + '%05d' % (img_num) + '.png',bbox_inches='tight')
    plt.draw()
    print img_num
    raw_input("press enter to advance")
    plt.clf()
    