import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import plot_light_cylinder
import sys
import random
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
import pickle
from sim_pars import *
from math import pi
from trajectory_utils import *
plt.ion()
fig = plt.figure()

def make_plots(traj_dict, keys_list = None, rescale=1., xmax=None, ymax=None, plot_lc=False, gamma_color_lim=[1.,1000.]):
    min_gamma = 500
    min_radius = .25*rs/Omega_rs_c
    cyl_min_radius = rs/Omega_rs_c
    r_frac = .75
    gamma_bool = False
    radius_bool = False
    cyl_radius_bool = True
    radius_reverse_bool = False
    
    if(xmax is None):
        xmax = 3.*rs/Omega_rs_c*rescale
    if(ymax is None):
        ymax = 1.5*rs/Omega_rs_c*rescale
    
    if keys_list == None:
        keys_list = traj_dict.keys()
    first_plot = True
    
    for n, key in enumerate(keys_list):
        if(gamma_condition(traj_dict,key,min_gamma,gamma_bool) \
            and radius_condition(traj_dict,key,min_radius,radius_bool) \
            and cyl_radius_condition(traj_dict,key,cyl_min_radius,cyl_radius_bool) \
            and radius_reverse_condition(traj_dict,key,r_frac,radius_reverse_bool)):
            r_arr = np.sqrt(traj_dict[key]['x']**2+traj_dict[key]['y']**2)*rescale
            z_arr = traj_dict[key]['z']*rescale
            lines = np.c_[r_arr[:-1], z_arr[:-1], r_arr[1:], z_arr[1:]]
            g_arr = np.sqrt(1 + traj_dict[key]['vx4']**2+traj_dict[key]['vy4']**2+traj_dict[key]['vz4']**2)
            line_collect = LineCollection(lines.reshape(-1, 2, 2), array=g_arr, linewidths=5,norm=plt.Normalize(gamma_color_lim[0], gamma_color_lim[1]))
            #fig, ax = pl.subplots()
            plt.axes().add_collection(line_collect)
            #ax.set_xlim(x.min(), x.max())
            #ax.set_ylim(y.min(), y.max())
            #fig.show()
            #plt.plot(r_arr, z_arr, lc)
            plt.axes().set_aspect('equal')
            plt.xlim(0,xmax)
            plt.ylim(-ymax,ymax)
            if(first_plot):
                axcb = fig.colorbar(line_collect)
                axcb.set_label('gamma factor')
                first_plot = False
            if(plot_lc):
                plot_light_cylinder(rs/Omega_rs_c,ymax)
            print key
            plt.draw()
            raw_input("press enter to advance")
            line_collect.remove()
            #plt.clf()

def plot_trajectory(traj_type,rescale=1.,keys_list=None, xmax=None, ymax=None, plot_lc=False, gamma_color_lim=[1.,1000.]):
    #create dictionary by which to sift particles
    if(traj_type == "ion"):
        traj_dict = pickle.load(open(indir+"traj_i.p","r"))
    elif(traj_type == "lec"):
        traj_dict = pickle.load(open(indir+"traj_e.p","r"))
    else:
        raise ValueError('trajectory type must be "lec" or "ion"')
        
    make_plots(traj_dict, rescale=rescale, keys_list=keys_list, xmax=xmax, ymax=ymax, plot_lc=plot_lc, gamma_color_lim=gamma_color_lim)

if __name__ == '__main__':
    traj_type = "ion"
    plot_lc = True
    #p_keys_list = [(2172,352620)]
    p_keys_list = None
    gamma_color_lim = [1.,20000.]
    plot_trajectory(traj_type,plot_lc=plot_lc,keys_list=p_keys_list,gamma_color_lim=gamma_color_lim)

