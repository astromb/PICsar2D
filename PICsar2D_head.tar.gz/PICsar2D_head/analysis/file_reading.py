import numpy as np
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from common import resample_dual, calc_grid_size_r, calc_grid_size_t
from scipy import ndimage

def read_fields(fname,n_flds,Nghost_r=Nghost_r,Nghost_t=Nghost_t):
    arr_dim_r = calc_grid_size_r()
    arr_dim_t = calc_grid_size_t()
    vol = arr_dim_r*arr_dim_t
    with open(fname, 'r') as f:
        flts = map(float,f)
    f.close()
    if(n_flds*vol != len(flts)):
        print "Nr: ", arr_dim_r, "Nt: ", arr_dim_t, "n_flds vol: ", n_flds*vol, "len flts: ", len(flts)
        raise ValueError("file length contradicts array lengths")
    fld_out_list = []
    for fld_i in range(n_flds):
        fld_out_list.append(np.array(flts[fld_i*vol:(fld_i+1)*vol]).reshape((arr_dim_t,arr_dim_r)))
    return fld_out_list

def read_fields_from_file(img_num,input_dir="",fld_type='flds'):
    if(input_dir == ""):
        input_dir = indir
    fname = input_dir + fld_type + '.' + '%05d' % img_num + '.d'
    return read_fields(fname,6,Nghost_r=Nghost_r,Nghost_t=Nghost_t)

def read_currents_from_file(img_num,input_dir=""):
    if(input_dir == ""):
        input_dir = indir
    fname = input_dir + 'cur.' + '%05d' % img_num + '.d'
    return read_fields(fname,3,Nghost_r=Nghost_r,Nghost_t=Nghost_t)

def read_inj_vol(img_num,fname_in=""):
    if(fname_in == ""):
        fname = indir+'inj_vol.' + '%05d' % img_num + '.d'
    else:
        fname = fname_in
    return read_fields(fname,2,Nghost_r=Nghost_r,Nghost_t=Nghost_t)

def read_prtl_dens(img_num,fname):
    [i_arr,e_arr] = read_fields(fname,2,Nghost_r=Nghost_r,Nghost_t=Nghost_t)
    i_arr = resample_dual(i_arr)
    e_arr = resample_dual(e_arr)
    return [i_arr,e_arr]

def read_prtl_header(l0):
    l0 = l0.split()
    n_ions = int(l0[0])
    n_lecs = int(l0[1])
    pdsample = int(l0[2])
    n_ions_dsample = int(l0[3])
    n_lecs_dsample = int(l0[4])
    return [n_ions,n_lecs,pdsample,n_ions_dsample,n_lecs_dsample]

def read_prtl_col(lines,n_prtl,offset,strt,pdsample):
    col_arr = np.zeros((n_prtl+pdsample-1)/pdsample)
    cnt = 0
    for n in range(0,n_prtl,pdsample):
        line_arr = lines[n+offset+1].split()
        if(len(line_arr) > 1):
            col_arr[cnt] = line_arr[strt]
            cnt += 1
    col_arr = col_arr[:cnt]
    return col_arr

def read_prtl_trpl(lines,n_prtl,offset,strt,pdsample):
    x_arr = np.zeros((n_prtl+pdsample-1)/pdsample)
    y_arr = np.zeros((n_prtl+pdsample-1)/pdsample)
    z_arr = np.zeros((n_prtl+pdsample-1)/pdsample)
    cnt = 0
    for n in range(0,n_prtl,pdsample):
        line_arr = lines[n+offset+1].split()
        if(len(line_arr) > 1):
            x = float(line_arr[strt])
            y = float(line_arr[strt+1])
            z = float(line_arr[strt+2])
            x_arr[cnt] = x
            y_arr[cnt] = y
            z_arr[cnt] = z
            cnt += 1
    x_arr = x_arr[:cnt]
    y_arr = y_arr[:cnt]
    z_arr = z_arr[:cnt]
    return [x_arr,y_arr,z_arr]

def read_prtl_triples_from_file(img_num,pdsample=1,strt=0):
    fname = indir + 'prtl.' + '%05d' % img_num + '.d'
    f = open(fname,'r')
    lines = f.readlines()
    f.close()
    [n_ions,n_lecs,pdsample_file,n_ions_dsample,n_lecs_dsample] = read_prtl_header(lines[0])
    cnt = 0
    [xi_arr,yi_arr,zi_arr] = read_prtl_trpl(lines,n_ions_dsample,0,strt,pdsample)
    [xe_arr,ye_arr,ze_arr] = read_prtl_trpl(lines,n_lecs_dsample,n_ions_dsample,strt,pdsample)
    print len(xi_arr), len(xe_arr)
    return [xi_arr,yi_arr,zi_arr,xe_arr,ye_arr,ze_arr]
        
def sort_tracers(cell_create_arr,n_create_arr,arr_list):
    inds2 = n_create_arr.argsort()
    n_create_arr = n_create_arr[inds2]
    cell_create_arr = cell_create_arr[inds2]
    inds1 = cell_create_arr.argsort()
    n_create_arr = n_create_arr[inds1]
    cell_create_arr = cell_create_arr[inds1]
    
    for i in range(0,len(arr_list)):
        arr_list[i] = arr_list[i][inds2]
        arr_list[i] = arr_list[i][inds1]
    return [zip(cell_create_arr,n_create_arr)] + arr_list

def read_tracer_one_type(lines,n_prtl,offset,pdsample):
    cell_create_arr = read_prtl_col(lines,n_prtl,offset,6,pdsample)
    n_create_arr = read_prtl_col(lines,n_prtl,offset,7,pdsample)
    [x_arr,y_arr,z_arr] = read_prtl_trpl(lines,n_prtl,offset,0,pdsample)
    [vx4_arr,vy4_arr,vz4_arr] = read_prtl_trpl(lines,n_prtl,offset,3,pdsample)
    return sort_tracers(cell_create_arr,n_create_arr,[x_arr,y_arr,z_arr,vx4_arr,vy4_arr,vz4_arr])

def read_tracers_from_file(img_num,pdsample=1):
    fname = indir + 'trcr.' + '%05d' % img_num + '.d'
    f = open(fname,'r')
    lines = f.readlines()
    f.close()
    [n_ions,n_lecs,pdsample_file,n_ions_dsample,n_lecs_dsample] = read_prtl_header(lines[0])
    pi_arr = read_tracer_one_type(lines,n_ions_dsample,0,pdsample)
    pe_arr = read_tracer_one_type(lines,n_lecs_dsample,n_ions_dsample,pdsample)
    return [pi_arr,pe_arr]

def read_poynting(img_num,indir_in="",fname_in=""):
    if(fname_in != ""):
        fname = fname_in
    else:
        if(indir_in == ""):
            indir_in = indir
        fname = indir_in + 'pynt.' + '%05d' % img_num + '.d'

    f = open(fname,'r')
    lines = f.readlines()
    f.close()
    pynt_arr = np.zeros(len(lines))
    ion_arr = np.zeros(len(lines))
    lec_arr = np.zeros(len(lines))
    r_arr = np.zeros(len(lines))
    for i,line in enumerate(lines):
        l_arr = line.split()
        r_arr[i] = float(l_arr[0])
        pynt_arr[i] = float(l_arr[1])
        if(len(l_arr) > 2):
            ion_arr[i] = float(l_arr[2])
            lec_arr[i] = float(l_arr[3])
    return [r_arr,pynt_arr,ion_arr,lec_arr]

def read_inj(img_num,fname_in=""):
    if(fname_in == ""):
        fname = indir+'inj_sur.' + '%05d' % img_num + '.d'
    else:
        fname = fname_in
    f = open(fname,'r')
    lines = f.readlines()
    f.close()
    data_arr = np.zeros(len(lines))
    for i,line in enumerate(lines):
        data_arr[i] = float(line)
    qsig_arr = np.array(data_arr[:len(lines)/2])
    ninj_arr = np.array(data_arr[len(lines)/2:])
    return [qsig_arr,ninj_arr]

def read_rot(img_num,input_dir="",fname_in=""):
    if(fname_in == ""):
        if(input_dir == ""):
            input_dir = indir 
        fname = input_dir + 'rot.' + '%05d' % img_num + '.d'
    else:
        fname = fname_in
    f = open(fname,'r')
    lines = f.readlines()
    f.close()
    data_arr = np.zeros(len(lines))
    r_arr = np.zeros(len(lines))
    for i,line in enumerate(lines):
        l_arr = line.split()
        r_arr[i] = float(l_arr[0])
        data_arr[i] = float(l_arr[1])
    return [r_arr,data_arr]
