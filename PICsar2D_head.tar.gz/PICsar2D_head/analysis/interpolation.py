import numpy as np
from math import pi
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from conversion import spher2grid

#Interpolate the value of the field at a point.
def interpol_field(pspher,field,grid_offset,grid_size):
    #convert from spherical grids to grid grids
    pgrid = spher2grid(pspher[0],pspher[1]) - grid_offset
    i = int(pgrid[0])
    j = int(pgrid[1])
    di = pgrid[0]-i
    dj = pgrid[1]-j
    #check if extrapolation is necessary near the edges of the domain
    if(i < 0):
        di -= 1
        i += 1
        if(i < 0):
            print i, pspher, pgrid, grid_offset
            raise ValueError("i is out of bounds in interpolation (too small)")
    elif(i+1 >= grid_size[0]):
        di += 1
        i -= 1
        if(i+1 >= grid_size[0]):
            raise ValueError("i is out of bounds in interpolation (too large)")
    if(j < 0):
        dj -= 1
        j += 1
        if(j < 0):
            raise ValueError("j is out of bounds in interpolation (too small)")
    elif(j+1 >= grid_size[1]):
        dj += 1
        j -= 1
        if(j+1 >= grid_size[0]):
            raise ValueError("j is out of bounds in interpolation (too large)")

    f00 = field[i,j]
    f10 = field[i+1,j]
    f01 = field[i,j+1]
    f11 = field[i+1,j+1]
    return f00*(1.-di)*(1.-dj) + f01*(1.-di)*dj + f10*di*(1.-dj) + f11*di*dj

#Interpolate an entire array to grid points
def remove_grid_offset(fin_arr,grid_offset,flipped=False):
    fout_arr = fin_arr
    if((grid_offset[0] and not flipped) or (grid_offset[1] and flipped)):
        fout_arr[1:,:] = .5*(fin_arr[1:,:] + fin_arr[:-1,:])
        #extrapolation near edges of the domain
        fout_arr[0,:] = 1.5*fin_arr[0,:] - .5*fin_arr[1,:]
        fout_arr[-1,:] = 1.5*fin_arr[-2,:] - .5*fin_arr[-3,:]
    if((grid_offset[1] and not flipped) or (grid_offset[0] and flipped)):
        fout_arr[:,1:] = .5*(fin_arr[:,1:] + fin_arr[:,:-1])
        #extrapolation near edges of the domain
        fout_arr[:,0] = 1.5*fin_arr[:,0] - .5*fin_arr[:,1]
        fout_arr[:,-1] = 1.5*fin_arr[:,-2] - .5*fin_arr[:,-3]
    
    return fout_arr