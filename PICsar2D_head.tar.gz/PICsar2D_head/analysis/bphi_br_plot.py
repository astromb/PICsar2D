import numpy as np
import matplotlib.pyplot as plt
import time
from file_reading import read_fields_from_file
from math import pi
from common import init_rt, convert_fnum_to_time
from sim_pars import *
from conversion import spher2grid

plt.ion()
rlc = rs/Omega_rs_c
vmin = -1
vmax = 1
start_img_num = 0
end_img_num = 10

[r_arr,rD_arr,th_arr,thD_arr] = init_rt()

bpbr_arr = np.zeros([Nt,Nr])

for img_num in range(start_img_num,end_img_num+1):
    [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
    for i in range(1,Nr): 
        bpbr_arr[:,i] = (bp_arr[:,i]+bp_arr[:,i-1])/(2*br_arr[:,i])
    #plot numerical solution
    
    r1 = .5*rlc
    r2 = rlc
    r3 = 1.5*rlc
    g1 = spher2grid(r1,0)
    g2 = spher2grid(r2,0)
    g3 = spher2grid(r3,0)
    i1 = g1[0]
    i2 = g2[0]
    i3 = g3[0]
    
    plt.ylim(-1.6,.2)
    plt.xlim(0,3.1416)
    plt.yticks([-1.6,-1.4,-1.2,-1.,-.8,-.6,-.4,-.2,0.,.2])
    p1, = plt.plot(thD_arr[:Nt-1],bpbr_arr[:Nt-1,i1],color='red',linewidth=1.5)
    p2, = plt.plot(thD_arr[:Nt-1],bpbr_arr[:Nt-1,i2],color='black',linewidth=1.5)
    p3, = plt.plot(thD_arr[:Nt-1],bpbr_arr[:Nt-1,i3],color='blue',linewidth=1.5)
    #plot analytic solution
    plt.plot(thD_arr[:Nt-1],-.5*np.sin(thD_arr[:Nt-1]),color='red',linestyle='dashed',linewidth=1.5)
    plt.plot(thD_arr[:Nt-1],-1.*np.sin(thD_arr[:Nt-1]),color='black',linestyle='dashed',linewidth=1.5)
    plt.plot(thD_arr[:Nt-1],-1.5*np.sin(thD_arr[:Nt-1]),color='blue',linestyle='dashed',linewidth=1.5)
    plt.xlabel(r"$\theta$ (radians)",fontsize=16)
    plt.ylabel(r"$B_\phi/B_r$",fontsize=18)
    plt.xticks(np.array([0,pi/4,pi/2,3*pi/4,pi]),np.array([r"$0$",r"$\pi/4$",r"$\pi/2$",r"$3\pi/4$",r"$\pi$"]))
    plt.tick_params(labelsize=16,axis='x')
    plt.tick_params(labelsize=14,axis='y')
    plt.legend([p1,p2,p3],[r"$r = R_{lc}/2$",r"$r = R_{lc}$",r"$r = 3R_{lc}/2$"],loc=4,frameon=False,fontsize=15)
    plt.text(2.0,0.05,'time (periods) = ' + convert_fnum_to_time(img_num),fontsize=15)
    print img_num
    #plt.savefig('bphibr.' + '%05d' % (img_num) + '.png',bbox_inches='tight')
    raw_input("press enter to advance")
    
    plt.clf()


    
