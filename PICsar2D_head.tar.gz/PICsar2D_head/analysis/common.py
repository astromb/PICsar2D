import numpy as np
from math import pi
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from math import exp

def init_rt(fds=1):
    Nr_full = Nr+2*Nghost_r*nproc_r
    Nt_full = Nt+2*Nghost_t*nproc_t
    r_arr = np.zeros(Nr_full)
    rD_arr = np.zeros(Nr_full)
    th_arr = np.zeros(Nt_full)
    thD_arr = np.zeros(Nt_full)
    
    if(logarithmic_r):
        for i in range(0,len(r_arr)):
            r_arr[i] = rs*exp((i - Nghost_r)/(1.0*rs))
            rD_arr[i] = rs*exp((i +.5 - Nghost_r)/(1.0*rs))
    else:
        for i in range(0,len(r_arr)):
            r_arr[i] = 1.0*rs + i - Nghost_r
            rD_arr[i] = r_arr[i] + .5
    
    if(equal_area_theta):
        dx = 2./(Nt-1)
        for j in range(0,len(th_arr)-1):
            th_arr[j] = np.arccos(-(dx*j-1))
            thD_arr[j] = np.arccos(-(dx*(j+.5)-1))
        th_arr[Nt-1] = pi
    else:
        dth = pi/(Nt-1)
        for j in range(0,len(th_arr)):
            th_arr[j] = j*dth
            thD_arr[j] = (j+.5)*dth
    return [r_arr[::fds],rD_arr[::fds],th_arr[::fds],thD_arr[::fds]]

def plot_light_cylinder(rlc,ylim):
    import matplotlib.pyplot as plt
    x = [rlc,rlc]
    y = [-ylim,ylim]
    plt.plot(x,y,color="black",linestyle="dashed",linewidth=2)

def draw_plot_ticks(xlim,ylim,dx,dy):
    import matplotlib.pyplot as plt
    plt.xticks(np.arange(xlim[0]*dx,xlim[1]*dx+1,dx),np.arange(xlim[0],xlim[1]+1,1),fontsize=14)
    plt.yticks(np.arange(ylim[0]*dy,ylim[1]*dy+1,dy),np.arange(ylim[0],ylim[1]+1,1),fontsize=14)
            
def draw_pulsar(rescale=1.,plot_xy=False):
    import matplotlib.pyplot as plt
    
    if(plot_xy):
        x = np.arange(-rs,rs+1.)
    else:
        x = np.arange(rs+1.)
    
    y1 = rescale*(rs**2-x**2)**.5
    y2 = -y1
    x*= rescale
    plt.fill_between(x,0,y1,color="gray",zorder=3)
    plt.fill_between(x,0,y2,color="gray",zorder=3)
    
def resample_dual(data_arr):
    import matplotlib.pyplot as plt
    data_arr1 = .5*(data_arr[:-2] + data_arr[1:-1])
    data_arr[-1] = data_arr[-2]
    data_arr[1:-1] = data_arr1
    return data_arr

def convert_fnum_to_time(fnum):
    return "%.3f" % ((start_write + fnum*write_stride)/(2*pi*rs/(c*Omega_rs_c)))

def vol(i,j,r,th):
    cell_vol = 2*pi*r
    if(equal_area_theta):
        cell_vol *= r*(2./(Nt-1))
    else:
        cell_vol *= r*sin(th)*(pi/(Nt-1))
    
    if(logarithmic_r):
        cell_vol *= np.exp(1.0*(i-Nghost_r)/rs)
    else:
        cell_vol *= 1
    return cell_vol    
    
def calc_grid_size_r():
    return (Nr+2*Nghost_r*nproc_r+fdsample-1)/fdsample

def calc_grid_size_t():
    return (Nt+2*Nghost_t*nproc_t+fdsample-1)/fdsample

P_X = 0
P_Y = 1
P_Z = 2
P_VX4 = 3
P_VY4 = 4
P_VZ4 = 5
P_CELLCREATE = 6
P_NCREATE = 7
P_TRACER = 8