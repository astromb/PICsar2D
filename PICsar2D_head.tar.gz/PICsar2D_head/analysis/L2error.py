import numpy as np
import time
import matplotlib.pyplot as plt
from math import pi,exp
from file_reading import read_fields_from_file
from sim_pars import *
from common import init_rt
def bz_anal(r,th,t,k,omega):
    P11val = -np.sin(th)
    return u1(k*r)/r*P11val*np.cos(omega*(t-.5))

def u1(r):
    return np.sin(r)/r - np.cos(r) 

plt.ion()
img_num=1

rescale = 1./rs
omega = k*c
bzr_arr = np.zeros( (Nt,Nr) )
bzr_anal_arr = np.zeros( (Nt,Nr) )
err_arr = np.zeros( (Nt,Nr) )

[r_arr,rD_arr,th_arr,thD_arr] = init_rt()

fname = '../output/flds.' + '%05d' % img_num + '.d'
f = open(fname,'r')
lines = f.readlines()
f.close()
vol = Nr*Nt
if(6*vol != len(lines)):
    raise ValueError("file length contradicts array lengths")

[ex_arr,ey_arr,ez_arr,bx_arr,by_arr,bz_arr] = read_fields_from_file(img_num)

for i in range(0,Nr):
    r = rD_arr[i]
    bzr_arr[:,i] = bz_arr[:,i]*r
    for j in range(0,Nt):
        th = thD_arr[j]
        if(i != Nr-1 and j != Nt-1):
            bzr_anal_arr[j,i] = bz_anal(r,th,tt,k,omega)*r
err_arr = bzr_arr-bzr_anal_arr
rmax = rs + Nr - 1
if(logarithmic_r): rmax = rs*exp(rmax/rs-1)
xlim = rmax*rescale
ylim = xlim
plt.xlim(0,xlim)
plt.ylim(-ylim,ylim)
plt.axes().set_aspect('equal')
plt.xlabel("cyl. radius ($R/R_0$)",fontsize=16)
plt.ylabel("z position ($z/R_0$)",fontsize=16)
rad,theta = np.meshgrid(r_arr,th_arr)
xx = rad*np.sin(theta)*rescale
zz = rad*np.cos(theta)*rescale
plt.pcolormesh(xx,zz,err_arr/np.amax(bzr_anal_arr))
print np.amax(np.abs(err_arr)), np.unravel_index(err_arr.argmax(),err_arr.shape) 
print (np.sum(err_arr**2)/np.sum(bzr_anal_arr**2))**.5
plt.colorbar()
plt.draw()
raw_input("press enter to advance")
plt.clf()