import numpy as np
import matplotlib.pyplot as plt
import time
from math import pi
from pylab import savefig
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from file_reading import read_poynting
from common import convert_fnum_to_time

plt.ion()
plot_lc = True
rlc = rs/Omega_rs_c

start_img_num = 10
end_img_num = 1000
img_stride = 10
rmax = 4*rs/Omega_rs_c
for img_num in range(start_img_num,end_img_num+1,img_stride):
    [r_arr,pynt_arr,ion_arr,lec_arr] = read_poynting(img_num)
    r_arr /= (rs/Omega_rs_c)
    if(is_dipole):
        scale_fac = 4*pi*c*(rs*B0*Omega_rs_c**2)**2
        ymax = 2.
    else:#monopole
        scale_fac = 8*pi/3*c*(rs*B0*Omega_rs_c)**2
        ymax = 1.3
    pynt_arr /= scale_fac
    ion_arr /= scale_fac
    lec_arr /= scale_fac
    p1, = plt.plot(r_arr,pynt_arr, color="black", linewidth=1.5)
    p2, = plt.plot(r_arr,lec_arr+ion_arr, color="blue", linewidth=1.5)
    p3, = plt.plot(r_arr,pynt_arr+ion_arr+lec_arr, color="red", linewidth=1.5)
    plt.legend([p1,p2,p3],["Poynting","particle","total"],loc=1,frameon=True,fontsize=15)
    plt.xlim(0,rmax/(rs/Omega_rs_c))
    plt.ylim(0,ymax)
    plt.xlabel("$R/R_{lc}$",fontsize=20)
    plt.ylabel("$L/L_0$",fontsize=20)
    plt.tick_params(labelsize=16)
    plt.draw()
    print img_num
    plt.text(0.2,.9*ymax,'time (periods) = ' + convert_fnum_to_time(img_num),fontsize=15)    
    #plt.savefig('poynt_' + '%05d' % (img_num) + '.png',bbox_inches='tight')
    raw_input("press enter to advance")
    plt.clf()
    
