import numpy as np
import matplotlib.pyplot as plt
import time
from pylab import savefig
import sys
sys.path.append("/Users/mbelyaev/Desktop/research/pulsar_svn/trunk/pulsar")
from sim_pars import *
from math import pi, exp
from common import init_rt, plot_light_cylinder, draw_pulsar, resample_dual, convert_fnum_to_time
from file_reading import read_currents_from_file, read_fields_from_file, read_prtl_dens
from scipy import ndimage

plot_colorbar = True
plot_lc = True
draw_psr = True
plot_fls = True
nfilt = 1
cmap='spectral'

plt.ion()
start_img_num = 10
end_img_num = 1000
img_stride = 1
rlc = rs/Omega_rs_c
[r_arr,rD_arr,th_arr,thD_arr] = init_rt(fds=fdsample)

rescale = 1.
if(plot_lc):
    rlc = rs/Omega_rs_c
    rescale = 1./rlc
    xlim = 3.
else:
    rescale = 1./rs
    xlim = r_arr[-1]*rescale
ylim = xlim/2.

if(plot_fls):
    from field_lines import plot_field_lines
    fline_rmax = min(1.5*xlim/rescale,r_arr[-1-Nlossy])
    fline_rmin = rs

for img_num in range(start_img_num,end_img_num+1,img_stride):
    print img_num
    fname = indir+'/ptlq.' + '%05d' % img_num + '.d'
    [qion_arr,qlec_arr] = read_prtl_dens(img_num,fname)
    fname = indir+'/ptlg.' + '%05d' % img_num + '.d'
    [gion_arr,glec_arr] = read_prtl_dens(img_num,fname)
    for n in range(0,nfilt):
        gion_arr = ndimage.gaussian_filter(gion_arr,1,mode="wrap")
        glec_arr = ndimage.gaussian_filter(glec_arr,1,mode="wrap")
        qion_arr = ndimage.gaussian_filter(qion_arr,1,mode="wrap")
        qlec_arr = ndimage.gaussian_filter(qlec_arr,1,mode="wrap")
    [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
    B2 = br_arr*br_arr+bt_arr*bt_arr+bp_arr*bp_arr
    data_arr = B2/((qion_arr*gion_arr-qlec_arr*glec_arr)*c*c)
    #divide by the volume of a cell
    for i in range(0,len(rD_arr)):
        data_arr[:,i] = data_arr[:,i]*(4*pi*rD_arr[i]*rD_arr[i]/(Nt-1)*exp(1.0*i/rs))
    data_arr = np.log10(data_arr)
    print data_arr.max(), data_arr.min(), np.unravel_index(data_arr.argmax(),data_arr.shape), np.unravel_index(data_arr.argmin(),data_arr.shape)
    #data_arr = np.sum(ninj_arr,axis=0)
    #data_arr = np.sum(abs(qsig_arr),axis=0)/Nt
    #plt.plot(jx_arr[(Nt-1)/2,:150])
    plt.xlim(0,xlim)
    plt.ylim(-ylim,ylim)
    plt.axes().set_aspect('equal')
    plt.xlabel("cyl. radius ($R/r_*$)",fontsize=16)
    plt.ylabel("z position ($z/r_*$)",fontsize=16)
    rad,theta = np.meshgrid(rD_arr,th_arr)
    
    xx = rad*np.sin(theta)*rescale
    zz = rad*np.cos(theta)*rescale
    plt.pcolormesh(xx,zz,data_arr,vmin=-1.,vmax=4.,cmap=cmap)
    
    if(plot_colorbar):
        plt.colorbar()
    if(draw_psr):
        draw_pulsar(rescale=rescale)
    if(plot_lc):
        plt.xlabel(r"$R/R_{lc}$",fontsize=16)
        plt.ylabel(r"$z/R_{lc}$",fontsize=16)
        plot_light_cylinder(1,ylim)
    else:
        plt.xlabel(r"$R/R_0$",fontsize=16)
        plt.ylabel(r"$z/R_0$",fontsize=16)
    if(plot_fls):
        [er_arr,et_arr,ep_arr,br_arr,bt_arr,bp_arr] = read_fields_from_file(img_num)
        fields = [br_arr.T,bt_arr.T]
        plot_field_lines(fields,[fline_rmin,fline_rmax],rescale=rescale)
    plt.savefig('magnetization_mode2_'+ '%05d' % img_num +'.png',bbox_inches='tight')
    raw_input("press enter to advance")
    plt.clf()
    
